
public class DataPoint {
	public String name;
	public int score;

	public DataPoint(String name, int score) {
		this.name = name;
		//if (score < 0)
			//	throw new IllegalArgumentException();
		this.score = score; 
	}
}
