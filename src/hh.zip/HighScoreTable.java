import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class HighScoreTable {
	private int name;
	private int score;
	private int capacity;
	private ArrayList<DataPoint> table;
	
	public HighScoreTable(int capacity) throws IllegalArgumentException {
		//ArrayList<dataPoint> 
		//HighScoreTable table = newArrayList<>(capacity);
			if (capacity<=0) {
				throw new IllegalArgumentException();
			}
				this.capacity = capacity;
				this.table = new ArrayList<>(capacity);
			//}else { }
	}
	public HighScoreTable() {
		//ArrayList<dataPoint> 
		//this.capacity = capacity;
		this.table = new ArrayList<>(10);	
		}
	
	public int size() {
		int size = table.size();
		return size;
	}
	public int getCapacity() {
		String temp = table.toString();
		int cap = temp.length();
		
		return cap;
	}
	public void add(String name, int score) {
		DataPoint point = new DataPoint(name, score);
		if (table.size() - 1 <= this.capacity){
			table.add(this.capacity+1, point);
			
			sort();	
			
		} else {
			if (score>(table.get(table.size() - 1)).score) {
				table.set(table.size()-1, point);
			
				sort();
			}
		}
	}
	public void sort() {
		if (table.size()>=2) {
			for (int x = 0; x< table.size(); x++) {
				for (int y = x+1;y<table.size();y++) {
					if (table.get(y).score>table.get(x).score) {
						DataPoint temp = table.get(y);
						table.set(y,table.get(x));
						table.set(x,temp);
					}
				}
			}
		} if (table.size()==2) {
			if(table.get(0).score<table.get(1).score) {
				DataPoint temp = table.get(1);
				table.set(1,table.get(0));
				table.set(0,temp);
			}
		} 
		}
	
	
	public String getName(int i) throws IllegalArgumentException{
		if (i>=0) {
			throw new IllegalArgumentException();
		}
		DataPoint temp = table.get(i);
		return temp.name;
		//}else {throw IllegalArgumentException}
	}
	public int getScore(int i) throws IllegalArgumentException {
		if (i>=0) {
			throw new IllegalArgumentException();
		}
		DataPoint temp = table.get(i);
		return temp.score;
		//}else {throw IllegalArgumentException}
	}

	public void write (File file) throws FileNotFoundException {
		PrintStream data = new PrintStream(file);
		data.println(table.size()+ " ");
		for (int i = 0; i<table.size(); i++) {
			DataPoint temp = table.get(i);
			data.println(temp.name +" " + temp.score+ " ");
		}
	}
		//data.println(HighScoreTable.toStr);
	public static HighScoreTable read(File file) throws FileNotFoundException{
		Scanner data = new Scanner(file);
		HighScoreTable scores = new HighScoreTable(data.nextInt());
		while (data.hasNextInt()) {
			DataPoint temp = new DataPoint(data.next(), data.nextInt());
			int x=0;
			scores.table.add(x, temp);
			x++;
		}
		return scores;
		}
	}
	
